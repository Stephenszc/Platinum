This directory has all our protein sequences filed using a naming system in preparation for the fasta Format for translation. All files are lsited according to the rank of the highest protein sequence in the list



1000seq   -	protein sequence from 1    to 1000
2000seq   -	protein sequence from 1001 to 2000
3000seq  -	protein sequence from 2001 to 3000
4000seq  -	protein sequence from 3001 to 4000
5000seq  -	protein sequence from 4001 to 5000
6000seq  -	protein sequence from 5001 to 6000
7000seq  -	protein sequence from 6001 to 7000
8000seq  -	protein sequence from 7001 to 8000
8795seq  -	protein sequence from 8001 to 8795

All Sequences  - All 8795 Sequences stored in one file

Please refer to the directory Fasta file for data already processed for loading into the Profeat server 
